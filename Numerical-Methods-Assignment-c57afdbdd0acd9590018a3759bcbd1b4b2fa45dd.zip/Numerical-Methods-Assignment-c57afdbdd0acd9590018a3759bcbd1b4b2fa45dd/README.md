# Numerical-Methods-Assignment
Cubic Spline and Lagrange Interpolation 
